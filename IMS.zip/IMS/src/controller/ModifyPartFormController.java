package controller;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.control.RadioButton;
import javafx.scene.control.TextField;
import javafx.scene.control.ToggleGroup;
import javafx.stage.Stage;
import model.InHouse;
import model.Inventory;
import model.Outsourced;

/**
 * FXML Controller class
 *
 * @author Daniel Cutrara
 */
public class ModifyPartFormController implements Initializable 
{
    /**
     * Radio buttons to select InHouse or Outsourced Supplier
     */
    @FXML private RadioButton InHouseRadioButton;
    @FXML private RadioButton OutsourcedRadioButton;
    @FXML private ToggleGroup partSupplierToggleGroup;
    @FXML private Label PartSourceLabel;
    @FXML private Label partModifyFieldsCompleteLabel;
    
    /**
     * Text Fields to enter Part data 
     */
    @FXML private TextField idTextBox;
    @FXML private TextField nameTextBox;
    @FXML private TextField invTextBox;
    @FXML private TextField priceTextBox;
    @FXML private TextField maxTextBox;
    @FXML private TextField minTextBox;
    @FXML private TextField labelTextBox;
    
    /**
     * This method initiates a selected Outsourced Part
     * to be transferred to the ModifyPartForm
     * @param part
     */
    public void transferSelectedPart(Outsourced part)
    {        
        System.out.println(part.getClass());
        idTextBox.setText(Integer.toString(part.getId()));
        nameTextBox.setText(part.getName());
        invTextBox.setText(Integer.toString(part.getStock()));
        priceTextBox.setText(Double.toString(part.getPrice()));
        maxTextBox.setText(Integer.toString(part.getMax()));
        minTextBox.setText(Integer.toString(part.getMin()));
        labelTextBox.setText(part.getCompanyName());
        partSupplierToggleGroup.selectToggle(OutsourcedRadioButton);
        if (this.partSupplierToggleGroup.getSelectedToggle()
                .equals(this.OutsourcedRadioButton))
            PartSourceLabel.setText("Company Name");
    }
    
    /**
     * This method initiates a selected InHouse Part 
     * to be transferred to the ModifyPartForm
     * @param part
     */
    public void transferSelectedPart(InHouse part) 
    {
        System.out.println(part.getClass());
        idTextBox.setText(Integer.toString(part.getId()));
        nameTextBox.setText(part.getName());
        invTextBox.setText(Integer.toString(part.getStock()));
        priceTextBox.setText(Double.toString(part.getPrice()));
        maxTextBox.setText(Integer.toString(part.getMax()));
        minTextBox.setText(Integer.toString(part.getMin())); 
        labelTextBox.setText(Integer.toString(part.getMachineId()));  
    }        
    
    /**
     * This method will update RadioButtonLabel to select InHouse or Outsourced
     */
    public void radioButtonChanged()
    {
        if (this.partSupplierToggleGroup.getSelectedToggle().equals(this.OutsourcedRadioButton))
            PartSourceLabel.setText("Company Name");
        
        if (this.partSupplierToggleGroup.getSelectedToggle().equals(this.InHouseRadioButton))
            PartSourceLabel.setText("Machine ID");
    }    
    
    /**
     * This method is called when the Cancel button is clicked 
     * @param event
     * @throws java.io.IOException
     * @throws NumberFormatException
     * RUNTIME ERROR - Implemented Try / Catch for NumberFormatException if 
     * user tries to save a new Part without filling in all necessary fields
     */
    public void ModifyPartSaveButton(ActionEvent event) throws IOException
    {
        outerloop:
        try
        {                   
            int id = Integer.parseInt(idTextBox.getText());
            String name = nameTextBox.getText();
            Double price = Double.parseDouble(priceTextBox.getText());
            int stock = Integer.parseInt(invTextBox.getText());
            int min = Integer.parseInt(minTextBox.getText());
            int max = Integer.parseInt(maxTextBox.getText());
            String source = PartSourceLabel.getText();
        
        if(min >= max) {
            partModifyFieldsCompleteLabel.setText("Inventory Minimum must be less than Maximum");
            break outerloop;   
        }       
        if(stock <= min) {
            partModifyFieldsCompleteLabel.setText("Inventory must be MORE than Minimum");
            break outerloop;
        }
        if(stock >= max) {
            partModifyFieldsCompleteLabel.setText("Inventory must be LESS than Maximum");
            break outerloop;
        }   
        if ("MachineID".equals(source))
        {
            int machineId = Integer.parseInt(labelTextBox.getText());      
            InHouse newPart = new InHouse(id, name, price, stock, min, max, machineId);
            int index = id - 1;
            Inventory.updatePart(index, newPart);   
        }
        else
        {
            String companyName = labelTextBox.getText();
            Outsourced newPart = new Outsourced(id, name,  price,  stock,  min,  max, companyName);
            int index = id - 1;
            Inventory.updatePart(index, newPart);   
        }
                
        Parent MainViewParent = FXMLLoader.load(getClass()
                .getResource("/view/mainForm.fxml"));
        Scene returnToMainFormScene = new Scene(MainViewParent);
        
        //This gets the stage
        Stage window = (Stage)((Node)event.getSource()).getScene().getWindow();
        window.setScene(returnToMainFormScene);
        window.show();    
        }
        catch(IOException | NumberFormatException e) 
        {
            partModifyFieldsCompleteLabel.setText
                ("Please enter complete data in all Part Fields");
        }
    }
    
    /**
     * This method is called when the Cancel button is clicked 
     * @param event
     * @throws java.io.IOException
     */
    public void ModifyPartFormCancelButton(ActionEvent event) throws IOException
    {
        Parent MainViewParent = FXMLLoader.load(getClass().getResource("/view/mainForm.fxml"));
        Scene modifyPartFormScene = new Scene(MainViewParent);
        
        //This gets the stage
        Stage window = (Stage)((Node)event.getSource()).getScene().getWindow();
        window.setScene(modifyPartFormScene);
        window.show();
    }
    
    /**
     * Initializes the controller class.
     * @param url
     * @param rb
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
 
        /*
            Provides Handling of Radio Buttons
        */
        partSupplierToggleGroup = new ToggleGroup();
        this.InHouseRadioButton.setToggleGroup(partSupplierToggleGroup);
        this.OutsourcedRadioButton.setToggleGroup(partSupplierToggleGroup);
        InHouseRadioButton.setSelected(true);
        PartSourceLabel.setText("Machine ID"); 
    }   
}