package controller;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;
import model.Inventory;
import model.Part;
import model.Product;

/**
 * FXML Controller class
 *
 * @author Daniel Cutrara
 */
public class AddProductFormController implements Initializable { 
    
    ObservableList<Part> associatedPartList = FXCollections.observableArrayList();
    /**
     * These fields establish the Parts TableView
     */    
    @FXML private TableView <Part> partDataTableView;
    @FXML private TableColumn<Part,Integer> partIdColumn;
    @FXML private TableColumn<Part,String> partNameColumn;
    @FXML private TableColumn<Part,Integer> invLevelColumn;
    @FXML private TableColumn<Part,Double> priceColumn;
    @FXML private TextField SearchTextBox;
    
    /**
     * These fields establish the Associated Parts TableView
     */    
    @FXML private TableView <Part> associatedPartTableView;
    @FXML private TableColumn<Part,Integer> AsspartIdColumn;
    @FXML private TableColumn<Part,String> AssPartNameColumn;
    @FXML private TableColumn<Part,Integer> AssInvLevelColumn;
    @FXML private TableColumn<Part,Double> AssPriceCollumn;
    
    /**
     * TextField's for Save Product Event  
     */
    @FXML private TextField productIdTextBox;
    @FXML private TextField productNameTextBox;
    @FXML private TextField productInvTextBox;
    @FXML private TextField productPriceTextBox;
    @FXML private TextField productMaxTextBox;
    @FXML private TextField productMinTextBox;
    @FXML private Label producttAddFieldsCompleteLabel;
    private Product newProduct;
    
    
    /**
     * This method is called when the Add Product button is clicked
     * @param event
     * @throws java.io.IOException
     */
    @FXML public void saveProductEvent(ActionEvent event) throws IOException
    {
        outerloop:
        try
        {
            getTempProduct();
            associatedPartList.addAll(newProduct.getAllAssociatedParts());
            
            Parent MainViewParent = FXMLLoader.load(getClass().getResource("/view/mainForm.fxml"));
            Scene modifyPartFormScene = new Scene(MainViewParent);

            //This gets the stage
            Stage window = (Stage)((Node)event.getSource()).getScene().getWindow();
            window.setScene(modifyPartFormScene);
            window.show();
        }
        catch(IOException | NumberFormatException e)
        {
            producttAddFieldsCompleteLabel.setText
                ("Please enter complete data in all Product Fields");
        }
    }
    
    /**
     * This method saves a New Product added when the Save button is clicked 
     * @param event
     * @throws IOException
     */
    public void AddProductFormCancelButton(ActionEvent event) throws IOException
    {
        Parent MainViewParent = FXMLLoader.load(getClass().
                getResource("/view/mainForm.fxml"));
        Scene modifyPartFormScene = new Scene(MainViewParent);
        
        //This gets the stage
        Stage window = (Stage)((Node)event.getSource()).getScene().getWindow();
        window.setScene(modifyPartFormScene);
        window.show();
    }
    
    /**
     * This methods adds an Associated Part to the selected Product 
     * @param event
     * @throws java.io.IOException
     */
    public void addAssociatedPartButton(ActionEvent event) throws IOException
    {        
        getTempProduct();
        
        if(partDataTableView.getSelectionModel().getSelectedItem() == null)
        {
          System.out.println("Pick a Part to add to Associated part List.");
          producttAddFieldsCompleteLabel.setText
            ("Pick a Part to add to Associated part List.");  
        }
        else
        {      
            Part addPart = partDataTableView.getSelectionModel().getSelectedItem();
            newProduct.addAssociatedPart(addPart);
            associatedPartList.add(addPart);
            associatedPartTableView.setItems(associatedPartList);
        }
    }
    
    /**
     * This method creates the new Product from data entered in Text Fields
     * @return
     * @throws java.io.IOException
     */
    public Product getTempProduct() throws IOException
    {
        outerloop:
        try
        {
            int id = Integer.parseInt(productIdTextBox.getText());
            String name = productNameTextBox.getText();
            int inv = Integer.parseInt(productInvTextBox.getText());
            double price = Double.parseDouble(productPriceTextBox.getText());
            int max = Integer.parseInt(productMaxTextBox.getText());
            int min = Integer.parseInt(productMinTextBox.getText());
            int index = id - 1;
            if(min > max) {
                producttAddFieldsCompleteLabel.setText("Inventory Minimum must be less than Maximum");
                break outerloop;   
            }  
            if(inv <= min){
                producttAddFieldsCompleteLabel.setText("Inventory must be MORE than Minimum");
                break outerloop;
            }
            if(inv >= max){
                producttAddFieldsCompleteLabel.setText("Inventory must be LESS than Maximum");
                break outerloop;
            }
            
            if(!(Inventory.lookupProduct(id) == null))
            {
                break outerloop;
            }
            
            newProduct = new Product(id, name, price, inv, min, max);
            Inventory.addProduct(newProduct);
            newProduct.getAllAssociatedParts().addAll(newProduct.getAllAssociatedParts());
            
            return newProduct;
        }
        catch(NumberFormatException e)
        {
            producttAddFieldsCompleteLabel.setText
                ("Please enter complete data in all Product Fields");
        }
        return null;
    }
  
    /**
     * This method performs a search Parts to add as an Associated Part to the Product
     * @param event
     */
    @FXML public void addProductSearchPart(ActionEvent event)
    {        
        try
        {
            partDataTableView.setItems(Inventory.getAllParts());
            producttAddFieldsCompleteLabel.setText("");
            int searchId = Integer.parseInt(SearchTextBox.getText());
            System.out.println(searchId);
            Inventory.lookupPart(searchId);
            int selectPart = searchId -1;
            partDataTableView.getSelectionModel().select(selectPart);
            
            if(!partDataTableView.getSelectionModel().isSelected(selectPart))
            {
                partDataTableView.getSelectionModel().select(null);
                System.out.println("Part NOT Found.");
                producttAddFieldsCompleteLabel.setText("Part NOT Found.");
            }
            else
            {
                System.out.println("Part Found.");
                producttAddFieldsCompleteLabel.setText("Part Found.");
            }
        }
        catch(NumberFormatException e)
        {
            String searchPart = SearchTextBox.getText().trim();
            System.out.println(searchPart);
            Inventory.lookupPart(searchPart);
            partDataTableView.getSelectionModel().select(null);
            partDataTableView.setItems(Inventory.getSearchParts());
            if(!(Inventory.getSearchParts().isEmpty()))
            {
                System.out.println("Part(s) Found.");
                producttAddFieldsCompleteLabel.setText("Part(s) Found.");
            }
            else
            {
                System.out.println("Part NOT Found.");
                producttAddFieldsCompleteLabel.setText("Part NOT Found.");
            }
            
            if(SearchTextBox.getText().isEmpty())
                producttAddFieldsCompleteLabel.setText("Enter a Part ID or Name to search");
        }
    }
    
    /**
     * Initializes the controller class.
     * @param url
     * @param rb
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
       
        partDataTableView.setItems(Inventory.getAllParts());
        partIdColumn.setCellValueFactory(new PropertyValueFactory<>("id"));
        partNameColumn.setCellValueFactory(new PropertyValueFactory("name"));
        invLevelColumn.setCellValueFactory(new PropertyValueFactory("stock"));
        priceColumn.setCellValueFactory(new PropertyValueFactory("price"));
        
        productIdTextBox.setText(String.valueOf(Inventory.productid));     
        
        /**
         * This initiates the associated Parts table on the Add Product page
         */
        
        AsspartIdColumn.setCellValueFactory(new PropertyValueFactory<>("id"));
        AssPartNameColumn.setCellValueFactory(new PropertyValueFactory("name"));
        AssInvLevelColumn.setCellValueFactory(new PropertyValueFactory("stock"));
        AssPriceCollumn.setCellValueFactory(new PropertyValueFactory("price"));   
    }      
}
