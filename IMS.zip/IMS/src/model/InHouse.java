package model;

/**
 * Java Class - InHouse
 * @author Daniel Cutrara
 */
public class InHouse extends Part {
    /**
     * This sets the field for the source type
     */
     private int machineId;
     
    /**
     * This sets the fields for the super class
     * @param id
     * @param name
     * @param price
     * @param stock
     * @param min
     * @param max
     * @param machineId
     */
    public InHouse(int id, String name, double price, int stock, int min, int max, int machineId) 
    {
        super(id, name, price, stock, min, max);       
        this.machineId = machineId;
    }
    
    /**
     * @param machineId the machineID to set
     */
    public void setMachineId(int machineId)
    {
        this.machineId = machineId;
    }
    
    /**
     * @return the machineId
     */
    public int getMachineId()
    {
        return machineId;
    }
}
