package Controllers;

import Model.InHouse;
import Model.Inventory;
import Model.Outsourced;
import Model.Part;
import Model.Product;
import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ButtonType;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;

/**
 * FXML Controller class
 * 
 * @author Daniel Cutrara
 */
public class mainFormController implements Initializable 
{
    @FXML private AnchorPane Main;  
    @FXML private TextField PartSearchTextField;
    @FXML private TextField ProductSearchTextField;
    @FXML private Label partExceptionsLabel;
    Stage stage;
    
    /**
     * These fields establish the Parts TableView
     */    
    @FXML private TableView <Part> PartsTableView;
    @FXML private TableColumn<Part,Integer> partId;
    @FXML private TableColumn<Part,String> partName;
    @FXML private TableColumn<Part,Integer> partInvLevel;
    @FXML private TableColumn<Part,Double> partPrice;
    
    /**
     * These fields establish the Products TableView
     */    
    @FXML private TableView<Product> ProductsTableView;
    @FXML private TableColumn<Product,Integer> productId;
    @FXML private TableColumn<Product,String> productName;
    @FXML private TableColumn<Product,Integer> productInvLevel;
    @FXML private TableColumn<Product,Double> productPrice;  
  
    /**
      * This method is called when the exit button or X is clicked
      * @param event 
      */   
    @FXML public void logout(ActionEvent event)
    {
        Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
        alert.setTitle("Exit");
        alert.setHeaderText("You are about to exit the Application");
        alert.setContentText("Are you sure?");
        
        if(alert.showAndWait().get() == ButtonType.OK)
        {
            stage = (Stage) Main.getScene().getWindow();
            stage.close();
        }
    }   
    
    /**
     * This method searches for Part entered in TextField 
     * when Search button is clicked
     * @param event
     */
    @FXML public void searchPart(ActionEvent event)
    {        
        try
        {
            PartsTableView.setItems(Inventory.getAllParts());
            partExceptionsLabel.setText("");
            int searchId = Integer.parseInt(PartSearchTextField.getText());
            System.out.println(searchId);
            Inventory.lookupPart(searchId);
            int selectPart = searchId -1;
            PartsTableView.getSelectionModel().select(selectPart);
            
            if(!PartsTableView.getSelectionModel().isSelected(selectPart))
            {
                PartsTableView.getSelectionModel().select(null);
                System.out.println("Part NOT Found.");
                partExceptionsLabel.setText("Part NOT Found.");
            }
            else
            {
                System.out.println("Part Found.");
                partExceptionsLabel.setText("Part Found.");
            }
        }
        catch(NumberFormatException e)
        {
            String searchPart = PartSearchTextField.getText().trim();
            System.out.println(searchPart);
            Inventory.lookupPart(searchPart);
            PartsTableView.getSelectionModel().select(null);
            PartsTableView.setItems(Inventory.getSearchParts());
            if(!(Inventory.getSearchParts().isEmpty()))
            {
                System.out.println("Part(s) Found.");
                partExceptionsLabel.setText("Part(s) Found.");
            }
            else
            {
                System.out.println("Part NOT Found.");
                partExceptionsLabel.setText("Part NOT Found.");
            }
            if(PartSearchTextField.getText().isEmpty())
                partExceptionsLabel.setText("Enter a Part ID or Name to search");
        }
    }

    /**
     * This method searches for a Product entered in a TextField
     * when the search button is clicked 
     * @param event
     */
    @FXML public void searchProduct(ActionEvent event)
    {
        //if(ProductSearchTextField.getText().isEmpty())
        //    partExceptionsLabel.setText("Enter a Product ID or Name to search");
        try
        {
            ProductsTableView.setItems(Inventory.getAllProducts());
            partExceptionsLabel.setText("");
            int searchId = Integer.parseInt(ProductSearchTextField.getText().trim());
            System.out.println(searchId);
            Inventory.lookupPart(searchId);
            int selectProduct = searchId -1;
            ProductsTableView.getSelectionModel().select(selectProduct);
            
            if(!ProductsTableView.getSelectionModel().isSelected(selectProduct))
            {
                ProductsTableView.getSelectionModel().select(null);
                System.out.println("Product NOT Found.");
                partExceptionsLabel.setText("Product NOT Found.");
            }
            else
            {
                System.out.println("Product Found.");
                partExceptionsLabel.setText("Product Found.");
            }    
        }
        catch(NumberFormatException e)
        {
            String searchProduct = ProductSearchTextField.getText().trim().toLowerCase();
            System.out.println(searchProduct);
            ProductsTableView.getSelectionModel().select(null);
            Inventory.lookupProduct(searchProduct);
            ProductsTableView.setItems(Inventory.getSearchProducts());
                
                if(!(Inventory.getSearchProducts().isEmpty()))
                {
                    System.out.println("Product(s) Found.");
                    partExceptionsLabel.setText("Product(s) Found.");                    
                }
                else
                {
                    System.out.println("Product NOT Found.");
                    partExceptionsLabel.setText("Product NOT Found.");
                }
                if(ProductSearchTextField.getText().isEmpty())
                    partExceptionsLabel.setText("Enter a Product ID or Name to search");
        }
    }
    
    /**
     * This method is called when the Add Part button is clicked
     * @param event
     * @throws java.io.IOException
    */
    public void changeToAddPart(ActionEvent event) throws IOException
    {
        Parent MainViewParent = FXMLLoader.load(getClass().getResource("/View/AddPart.fxml"));
        Scene ModifyPartFormScene = new Scene(MainViewParent);
        
        //This gets the stage
        Stage window = (Stage)((Node)event.getSource()).getScene().getWindow();
        window.setScene(ModifyPartFormScene);
        window.show();
    }
    
    /**
     * This method is called when the Modify Part button is clicked
     * @param event
     * @throws IOException
     **/
    public void changeToModifyPartForm(ActionEvent event) throws IOException
    {
        try
        {
            FXMLLoader loader = new FXMLLoader();
            loader.setLocation((getClass().getResource("/View/ModifyPartForm.fxml")));
            Parent TableViewParent = loader.load();

            // Call the controller and access a method
            Scene ModifyPartFormScene = new Scene(TableViewParent);
            ModifyPartFormController controller = loader.getController();

            if(PartsTableView.getSelectionModel().getSelectedItem() == null)
            {
                System.out.println("Pick a Part to Modify.");
                partExceptionsLabel.setText("Please pick a Part to Modify.");
            }        
            else if(PartsTableView.getSelectionModel().getSelectedItem().getClass() == Outsourced.class)
                {
                    controller.transferSelectedPart((Outsourced) 
                            PartsTableView.getSelectionModel().getSelectedItem());
                    //This gets the stage
                    Stage window = (Stage)((Node)event.getSource()).getScene().getWindow();
                    window.setScene(ModifyPartFormScene);
                    window.show();  
                }
                else
                {
                    controller.transferSelectedPart((InHouse) 
                            PartsTableView.getSelectionModel().getSelectedItem());
                    //This gets the stage
                    Stage window = (Stage)((Node)event.getSource()).getScene().getWindow();
                    window.setScene(ModifyPartFormScene);
                    window.show();  
                }
        }
        catch(IOException | NumberFormatException e) 
        {
            partExceptionsLabel.setText("Please pick a Part to Modify.");
        }
    }     
           
    /**
     * This method is called when the Add Product button is clicked
     * @param event
     * @throws IOException
     */
     public void changeToAddProductForm(ActionEvent event) throws IOException
    {
        Parent MainViewParent = FXMLLoader.load(getClass().getResource("/View/AddProductForm.fxml"));
        Scene ModifyPartFormScene = new Scene(MainViewParent);
        
        //This gets the stage
        Stage window = (Stage)((Node)event.getSource()).getScene().getWindow();
        window.setScene(ModifyPartFormScene);
        window.show();
    }
     
    /**
     * This method is called when the Modify Product button is clicked
     * @param event
     * @throws IOException
     */
    public void changeToModifyProductForm(ActionEvent event) throws IOException
    {
        try
        {
            //System.out.print("Test Test");
            FXMLLoader loader = new FXMLLoader();
            loader.setLocation(getClass().getResource("/View/ModifyProductForm.fxml"));
            loader.load();
            
            ModifyProductFormController mpfc = loader.getController();
            mpfc.transferSelectedProduct(ProductsTableView.getSelectionModel().getSelectedItem());
            
            stage = (Stage)((Button)event.getSource()).getScene().getWindow();
            Parent scene = loader.getRoot();
            stage.setScene(new Scene(scene));
            stage.show();      
        }
        catch(IOException e) 
        {
            System.out.println(e.getMessage());
            //partExceptionsLabel.setText("Please pick a product to Modify.");
        }
    }
    
    /**
     * This method deletes a selected part when the delete button is clicked
     * @param event
     */
    @FXML public void DeletePart(ActionEvent event)
    {
        if(PartsTableView.getSelectionModel().getSelectedItem() == null)
        {
            System.out.println("Pick a Part to Delete.");
            partExceptionsLabel.setText("Please pick a Part to Delete.");
        }
        else
        {
            Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
            alert.setTitle("Delete");
            alert.setHeaderText("Delete Part");
            alert.setContentText("Are you sure?");

            if(alert.showAndWait().get() == ButtonType.OK)
            {
                Inventory.deletePart(PartsTableView.getSelectionModel().getSelectedItem());
                partExceptionsLabel.setText("Part Deleted Successfully.");
            }
        }
    }    
    
    /**
     * This method deletes a selected product when the delete button is clicked
     * @param event
     */
    @FXML public void DeleteProduct(ActionEvent event)
    {
        Product selectedProduct = ProductsTableView.getSelectionModel().getSelectedItem();
        if(selectedProduct == null)
        {
            System.out.println("Pick a Product to Delete");
            partExceptionsLabel.setText("Please pick a Product to Delete.");
        }
        else if(selectedProduct.getAllAssociatedParts().isEmpty())
        {
            Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
            alert.setTitle("Delete");
            alert.setHeaderText("Delete Product");
            alert.setContentText("Are you sure?");
        
            if(alert.showAndWait().get() == ButtonType.OK)
            {
                Inventory.deleteProduct(ProductsTableView.getSelectionModel().getSelectedItem());
                partExceptionsLabel.setText("Product Deleted Successfully.");
            }
        }
        else 
        {
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("ERROR");
            alert.setHeaderText("Currently Unable to Delete Product!");
            alert.setContentText("Product has Associated Parts");
        
            if(alert.showAndWait().get() == ButtonType.OK)
                
            partExceptionsLabel.setText("Unable to Deleted Product due to associated Parts.");
        }
    }
        
    @Override
    public void initialize(URL url, ResourceBundle rb) 
    {
        
        PartsTableView.setItems(Inventory.getAllParts());
        partId.setCellValueFactory(new PropertyValueFactory<>("id"));
        partName.setCellValueFactory(new PropertyValueFactory("name"));
        partInvLevel.setCellValueFactory(new PropertyValueFactory("stock"));
        partPrice.setCellValueFactory(new PropertyValueFactory("price"));
        
        ProductsTableView.setItems(Inventory.getAllProducts());
        productId.setCellValueFactory(new PropertyValueFactory("id"));
        productName.setCellValueFactory(new PropertyValueFactory("name"));
        productInvLevel.setCellValueFactory(new PropertyValueFactory("stock"));
        productPrice.setCellValueFactory(new PropertyValueFactory("price"));   
    }
}
        
        
        
