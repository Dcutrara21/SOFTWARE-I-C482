package Controllers;

import Model.Inventory;
import Model.Part;
import Model.Product;
import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.ButtonType;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;

/**
 * FXML Controller class
 *
 * @author Daniel Cutrara
 */
public class ModifyProductFormController implements Initializable 
{
    ObservableList<Part> associatedPartList = FXCollections.observableArrayList();
    /**
     * These fields establish the Parts TableView
     */    
    @FXML private TableView <Part> ModPartDataTableView;
    @FXML private TableColumn<Part,Integer> partIdColumn;
    @FXML private TableColumn<Part,String> partNameColumn;
    @FXML private TableColumn<Part,Integer> invLevelColumn;
    @FXML private TableColumn<Part,Double> priceColumn;
    @FXML private TextField SearchTextBox;
    @FXML private Label productMODFieldsCompleteLabel;
    
    /**
     * These fields establish the Associated Parts TableView
     */    
    @FXML private TableView <Part> ModAssociatedPartTableView;
    @FXML private TableColumn<Part,Integer> AsspartIdColumn;
    @FXML private TableColumn<Part,String> AssPartNameColumn;
    @FXML private TableColumn<Part,Integer> AssInvLevelColumn;
    @FXML private TableColumn<Part,Double> AssPriceCollumn;
    
    /**
     * TextField's for Save Modification Product Event  
     */
    private Product selectedProduct;
    @FXML private TextField productIdTextBox;
    @FXML private TextField productNameTextBox;
    @FXML private TextField productInvTextBox;
    @FXML private TextField productPriceTextBox;
    @FXML private TextField productMaxTextBox;
    @FXML private TextField productMinTextBox;
    
    /**
     * This method initiates a selected Product to be transferred to the ModifyProductForm
     * @param product
     */
    public void transferSelectedProduct(Product product)
    {
        selectedProduct = product;
        productIdTextBox.setText(Integer.toString(selectedProduct.getId()));
        productNameTextBox.setText(selectedProduct.getName());
        productInvTextBox.setText(Integer.toString(selectedProduct.getStock()));
        productPriceTextBox.setText(Double.toString(selectedProduct.getPrice()));
        productMaxTextBox.setText(Integer.toString(selectedProduct.getMax()));
        productMinTextBox.setText(Integer.toString(selectedProduct.getMin())); 

        /**
        * This initiates the associated Parts table on the Modify Part page
        */
        associatedPartList.addAll(selectedProduct.getAllAssociatedParts());
        
        ModAssociatedPartTableView.setItems(selectedProduct.getAllAssociatedParts());
        AsspartIdColumn.setCellValueFactory(new PropertyValueFactory<>("id"));
        AssPartNameColumn.setCellValueFactory(new PropertyValueFactory("name"));
        AssInvLevelColumn.setCellValueFactory(new PropertyValueFactory("stock"));
        AssPriceCollumn.setCellValueFactory(new PropertyValueFactory("price")); 
    }  
    
    /**
     * This method saves changes made to Modify a Product
     * @param event
     * @throws IOException
     */
    public void ModifyProductSaveButton(ActionEvent event) throws IOException
    {
        outerloop:
        try
        {
        int id = Integer.parseInt(productIdTextBox.getText());
        String name = productNameTextBox.getText();
        int stock = Integer.parseInt(productInvTextBox.getText());
        Double price = Double.parseDouble(productPriceTextBox.getText());
        int max = Integer.parseInt(productMaxTextBox.getText());
        int min = Integer.parseInt(productMinTextBox.getText());
        Product newProduct = new Product(id, name, price, stock, min, max);
        int index = id - 1;
        
        if(min > max) {
            productMODFieldsCompleteLabel.setText("Inventory Minimum must be less than Maximum");
            break outerloop;   
        }     
        if(stock <= min) {
            productMODFieldsCompleteLabel.setText("Inventory must be MORE than Minimum");
            break outerloop;
        }   
        if(stock >= max) {
            productMODFieldsCompleteLabel.setText("Inventory must be LESS than Maximum");
            break outerloop;
        }   
        
        newProduct.getAllAssociatedParts().addAll(selectedProduct.getAllAssociatedParts());
        Inventory.updateProduct(index, newProduct);
        
        Parent MainViewParent = FXMLLoader.load(getClass().getResource("/View/mainForm.fxml"));
        Scene returnToMainFormScene = new Scene(MainViewParent);
        
        //This gets the stage
        Stage window = (Stage)((Node)event.getSource()).getScene().getWindow();
        window.setScene(returnToMainFormScene);
        window.show();
        }
        catch(IOException e)
        {
            productMODFieldsCompleteLabel.setText
                ("Please enter complete data in all Product Fields");
        }
    }
        
    /**
     * This method is called when the Cancel button is clicked 
     * @param event
     * @throws java.io.IOException
     */
    public void ModifyProductFormCancelButton(ActionEvent event) throws IOException
    {
        selectedProduct.getAllAssociatedParts().clear();
        selectedProduct.getAllAssociatedParts().addAll(associatedPartList);
        Parent MainViewParent = FXMLLoader.load(getClass().getResource("/View/mainForm.fxml"));
        Scene modifyPartFormScene = new Scene(MainViewParent);
        
        //This gets the stage
        Stage window = (Stage)((Node)event.getSource()).getScene().getWindow();
        window.setScene(modifyPartFormScene);
        window.show();
    }
    
    /**
     * This methods adds an Associated Part to Product 
     * @param event
     */
    public void addAssociatedPartButton(ActionEvent event)
    {
        if(ModPartDataTableView.getSelectionModel().getSelectedItem() == null)
        {
          System.out.println("Pick a Part to add to Associated part List.");
          productMODFieldsCompleteLabel.setText
            ("Pick a Part to add to Associated part List.");  
        }
        else
        {
            Part addPart = ModPartDataTableView.getSelectionModel().getSelectedItem();
            selectedProduct.addAssociatedPart(addPart);
            System.out.println(ModPartDataTableView.getSelectionModel().getSelectedItem());
        }
    }
    
    /**
     * This method deletes an Associated Part to a Product
     * @param event
     */
    public void deleteAssociatedPart(ActionEvent event)
    {
         if(ModAssociatedPartTableView.getSelectionModel().getSelectedItem() == null)
        {
            System.out.println("Pick a Part to Delete.");
            productMODFieldsCompleteLabel.setText("Please pick a Part to Delete.");
        }
        else
        {
            Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
            alert.setTitle("Delete");
            alert.setHeaderText("Delete Associated Part");
            alert.setContentText("Are you sure?");

            if(alert.showAndWait().get() == ButtonType.OK)
            {
                selectedProduct.deleteAssociatedPart(ModAssociatedPartTableView.getSelectionModel().getSelectedItem());
                productMODFieldsCompleteLabel.setText("Part Deleted Successfully.");
            }
        }
    }
    
    /**
     * This method searches the list of Parts to select a part to associate to a product
     * @param event
     */
    @FXML public void modProductSearchPart(ActionEvent event)
    {        
        try
        {
            ModPartDataTableView.setItems(Inventory.getAllParts());
            productMODFieldsCompleteLabel.setText("");
            int searchId = Integer.parseInt(SearchTextBox.getText());
            System.out.println(searchId);
            Inventory.lookupPart(searchId);
            int selectPart = searchId -1;
            ModPartDataTableView.getSelectionModel().select(selectPart);
            
            if(!ModPartDataTableView.getSelectionModel().isSelected(selectPart))
            {
                ModPartDataTableView.getSelectionModel().select(null);
                System.out.println("Part NOT Found.");
                productMODFieldsCompleteLabel.setText("Part NOT Found.");
            }
            else
            {
                System.out.println("Part Found.");
                productMODFieldsCompleteLabel.setText("Part Found.");
            }
        }
        catch(NumberFormatException e)
        {
            String searchPart = SearchTextBox.getText().trim();
            System.out.println(searchPart);
            Inventory.lookupPart(searchPart);
            ModPartDataTableView.getSelectionModel().select(null);
            ModPartDataTableView.setItems(Inventory.getSearchParts());
            if(!(Inventory.getSearchParts().isEmpty()))
            {
                System.out.println("Part(s) Found.");
                productMODFieldsCompleteLabel.setText("Part(s) Found.");
            }
            else
            {
                System.out.println("Part NOT Found.");
                productMODFieldsCompleteLabel.setText("Part NOT Found.");
            }
            if(SearchTextBox.getText().isEmpty())
                productMODFieldsCompleteLabel.setText("Enter a Part ID or Name to search");
        }
    }
    
    /**
     * Initializes the controller class.
     * @param url
     * @param rb
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        
        ModPartDataTableView.setItems(Inventory.getAllParts());
        partIdColumn.setCellValueFactory(new PropertyValueFactory<>("id"));
        partNameColumn.setCellValueFactory(new PropertyValueFactory("name"));
        invLevelColumn.setCellValueFactory(new PropertyValueFactory("stock"));
        priceColumn.setCellValueFactory(new PropertyValueFactory("price"));        
    }    
}
