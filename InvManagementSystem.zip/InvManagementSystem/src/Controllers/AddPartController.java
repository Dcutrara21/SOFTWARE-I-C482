package Controllers;

import Model.InHouse;
import Model.Inventory;
import Model.Outsourced;
import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.control.RadioButton;
import javafx.scene.control.TextField;
import javafx.scene.control.ToggleGroup;
import javafx.stage.Stage;

/**
 * FXML Controller class
 *
 * @author Daniel Cutrara
 */
public class AddPartController implements Initializable 
{
     /**
     * Radio buttons to select InHouse or Outsourced Supplier
     */
    @FXML private RadioButton InHouseRadioButton;
    @FXML private RadioButton OutsourcedRadioButton;
    @FXML private ToggleGroup partSupplierToggleGroup;
    
    /**
     * TextField's for Save Part Event  
     */
    @FXML private Label PartSourceLabel;
    @FXML private TextField idTextBox;
    @FXML private TextField nameTextBox;
    @FXML private TextField invTextBox;
    @FXML private TextField priceTextBox;
    @FXML private TextField maxTextBox;
    @FXML private TextField minTextBox ;
    @FXML private TextField labelTextBox;
    @FXML private Label partAddFieldsCompleteLabel;
    
    /**
     * This method saves a new Part when the save button is clicked 
     * @param event
     * @throws IOException
     */
    @FXML@SuppressWarnings("empty-statement")
    public void savePartEvent(ActionEvent event) throws IOException
    {
        outerloop:
        try
        {
            int id = Integer.parseInt(idTextBox.getText());
            String name = nameTextBox.getText();
            double price = Double.parseDouble(priceTextBox.getText());
            int stock = Integer.parseInt(invTextBox.getText());
            int max = Integer.parseInt(maxTextBox.getText());
            int min = Integer.parseInt(minTextBox.getText());
            String label = labelTextBox.getText().trim();
            partSupplierToggleGroup.getToggles();
            boolean source;
            
            if(min >= max) {
                partAddFieldsCompleteLabel.setText("Inventory Minimum must be less than Maximum");
                break outerloop;
            }   
            if(stock <= min){
                partAddFieldsCompleteLabel.setText("Inventory must be MORE than Minimum");
                break outerloop;
            }
            if(stock >= max){
                partAddFieldsCompleteLabel.setText("Inventory must be LESS than Maximum");
                break outerloop;
            }     
        
            if("MachineID".equals(label))
            {
                source = true;
                int machineId = Integer.parseInt(labelTextBox.getText()); 
               
                Inventory.addPart(new InHouse(id, name, price, stock, max, min, machineId));
                Inventory.partid = id + 1;
                
                Parent MainViewParent = FXMLLoader.load(getClass().getResource("/View/mainForm.fxml"));
                Scene modifyPartFormScene = new Scene(MainViewParent);

                //This gets the stage
                Stage window = (Stage)((Node)event.getSource()).getScene().getWindow();
                window.setScene(modifyPartFormScene);
                window.show();
            }
            else
            {
                source = false;
                String companyName = labelTextBox.getText();
                if(nameTextBox != null)
                {
                Inventory.addPart(new Outsourced(id, name, price, stock, max, min, companyName));
                Inventory.partid = id + 1;
                
                Parent MainViewParent = FXMLLoader.load(getClass().getResource("/View/mainForm.fxml"));
                Scene modifyPartFormScene = new Scene(MainViewParent);

                //This gets the stage
                Stage window = (Stage)((Node)event.getSource()).getScene().getWindow();
                window.setScene(modifyPartFormScene);
                window.show();
                }
            }  
        }
        catch(IOException | NumberFormatException e) 
        {
            partAddFieldsCompleteLabel.setText("Please enter complete data in all Part Fields");
        }
    }
    
    /**
     * This method will update RadioButtonLabel to select InHouse or Outsourced
     */
    public void radioButtonChanged()
    {
        if (this.partSupplierToggleGroup.getSelectedToggle().equals(this.OutsourcedRadioButton))
            PartSourceLabel.setText("Company Name");
        
        if (this.partSupplierToggleGroup.getSelectedToggle().equals(this.InHouseRadioButton))
            PartSourceLabel.setText("Machine ID");
    }
    
    /**
     * This method is called when the Cancel button is clicked 
     * @param event
     * @throws java.io.IOException
     */
    public void AddPartFormCancelButton(ActionEvent event) throws IOException
    {
        Parent MainViewParent = FXMLLoader.load(getClass().getResource("/View/mainForm.fxml"));
        Scene modifyPartFormScene = new Scene(MainViewParent);
        
        //This gets the stage
        Stage window = (Stage)((Node)event.getSource()).getScene().getWindow();
        window.setScene(modifyPartFormScene);
        window.show();
    }
    
    /**
     * Initializes the controller class.
     * @param url
     * @param rb
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) 
    {
        // Handling of Radio Buttons
        partSupplierToggleGroup = new ToggleGroup();
        this.InHouseRadioButton.setToggleGroup(partSupplierToggleGroup);
        this.OutsourcedRadioButton.setToggleGroup(partSupplierToggleGroup);
        InHouseRadioButton.setSelected(true);
        PartSourceLabel.setText("Machine ID"); 
        
        idTextBox.setText(String.valueOf(Inventory.partid));       
    }    
}