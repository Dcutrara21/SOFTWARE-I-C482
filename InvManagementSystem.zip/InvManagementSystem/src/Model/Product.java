package Model;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;

/**
 *
 * @author Daniel Cutrara
 */
public class Product {
    
    ObservableList<Part> allAssociatedParts = FXCollections.observableArrayList();
    
    /**
     * This sets the fields for the Product Class
     */
    private int id;
    private String name;
    private double price;
    private int stock;
    private int min;
    private final int max;
    
    public Product(int id, String name, double price, int stock, int min, int max)
    {
        this.id = id;
        this.name = name;
        this.price = price;
        this.stock = stock;
        this.min = min;
        this.max = max;
    }
    
    /**
     * @param id the id to set
     */
    public void setId(int id) 
    {
        this.id = id;
    }
    
    /**
     * @param name
     */
    public void setName(String name) 
    {
        this.name = name;
    }
    
    /**
     * @param price the price is set
     */
    public void setPrice(double price)
    {
        this.price = price;
    }
    
    /**
     * @param stock the stock is set
     */
    public void setStock(int stock)
    {
        this.stock = stock;
    }
    
    /**
     * @param min the min is set
     */
    public void setMin(int min)
    {
        this.min = min;
    }
    
    /**
     * @return the id
     */
    public int getId() 
    {
        return id;
    }
    
    /**
     * @return the name
     */
    public String getName() 
    {
        return name;
    }
    
    /**
     * @return the price
     */
    public double getPrice()
    {
        return price;
    }
    
    /**
     * @return the stock 
     */
    public int getStock()
    {
        return stock;
    }
    
    /**
     * @return the min 
     */
    public int getMin()
    {
        return min;
    }
    
    /**
     * @return the max
     */
    public int getMax()
    {
        return max;
    }
    
    /**
     * Adds a part to the Associated Part list
     * @param part
     */
    public void addAssociatedPart(Part part)
    {
        allAssociatedParts.add(part);   
    }
    
    /**
     * This method deletes the selected part from the Associate Parts list
     * @param part
     * @return
     */
    public boolean deleteAssociatedPart(Part part)
    {
        
        boolean result = allAssociatedParts.remove(part);
        if(result)
            return result;
        return false;
    }
    
    /**
     * This Method returns all Associated Parts
     * @return
     */
    public ObservableList<Part> getAllAssociatedParts()
    {                 
        return allAssociatedParts;  
    }  
}