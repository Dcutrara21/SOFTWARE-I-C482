package Model;

/**
 * Outsourced Java Class
 * 
 * @author Daniel Cutrara
 */
public class Outsourced extends Part {

    /**
     * This sets the field for the source type
     */
    private String companyName;
    
    /**
     * This sets the fields for the super class
     * @param id
     * @param name
     * @param price
     * @param stock
     * @param min
     * @param max
     * @param companyName
     */
    public Outsourced(int id, String name, double price, int stock, int min, int max, String companyName) {
        super(id, name, price, stock, min, max);
        this.companyName = companyName;
    }
    
    /**
     * @param companyName the companyName to set
     */
    public void setComanyName(String companyName)
    {
        this.companyName = companyName;
    }
    
    /**
     * @return the companyName
     */
    public String getCompanyName()
    {
        return companyName;
    }
}