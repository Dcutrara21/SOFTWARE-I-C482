package model;

import java.io.IOException;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;

/**
 * Java Class - Inventory
 * @author Daniel Cutrara
 */
public class Inventory {
     
    private static final ObservableList<Part> allParts = FXCollections.observableArrayList();
    private static final ObservableList<Part> searchParts = FXCollections.observableArrayList();
    private static final ObservableList<Product> allProducts = FXCollections.observableArrayList();
    private static final ObservableList<Product> searchProducts = FXCollections.observableArrayList();
    
    public static int partid;
    public static int productid;
    public static String searchResults;   

    /**
     * This method adds a new Part to the allParts list
     * @param newPart
     */
    public static void addPart(Part newPart)
    {
        allParts.add(newPart);
    }
    
    /**
     * This method adds a new Product to the All Products list
     * @param newProduct
     */
    public static void addProduct(Product newProduct)
    {
        allProducts.add(newProduct);
    }
        
    /**
     * This method looks up a part by the Part # and returns ID if found
     * @param partId
     * @return the partId
     */
    public static Part lookupPart(int partId)
    {
        for(Part part : getAllParts())
        {
           if(part.getId() == partId)
           {            
               System.out.println(part);
               return part;
           }
        }
        return null;
    }
       
     /**
     * This method looks up a part by the Part # and returns ID if found
     * @param productId
     * @return the partId
     */
    public static Product lookupProduct(int productId)
    {        
        for(Product product : getAllProducts())
        {
            if(product.getId() == productId)
            {   
                System.out.println(product);
                return product;
            }
        }
        return null;
    }
       
    /**
     * This method looks up a part by the Part Name
     * @param name
     * @return the partId
     */
    public static ObservableList<Part> lookupPart(String name)
    {
        if(!(getSearchParts().isEmpty()))
        {
            getSearchParts().clear();
        }
        
        for(Part searchPart : getAllParts())
        {
            if(searchPart.getName().toLowerCase().contains(name.toLowerCase()))
            {  
                getSearchParts().add(searchPart);
                System.out.println(searchPart);
            }
        }
        return null;
    }
        
    /**
     * This method looks up a Product by Product Name
     * @param name
     * @return the productId
     */   
    public static ObservableList<Product> lookupProduct(String name)
    {
        if(!(getSearchProducts().isEmpty()))
        {
            getSearchProducts().clear();
        }
        for(Product searchProduct : getAllProducts())
        {
            if(searchProduct.getName().toLowerCase().contains(name.toLowerCase()))
            {  
                getSearchProducts().add(searchProduct);
                System.out.println(searchProduct);
            }
        }
        return null;
    }
    
    /**
     * This method implements updates to a selected Part
     * 
     * @param index
     * @param selectedPart
     */
    public static void updatePart(int index, Part selectedPart)
    {
        allParts.set(index, selectedPart);
    }
        
    /**
     * This method implements updates to a selected Product
     * @param index
     * @param newProduct
     * @throws java.io.IOException
     */
    public static void updateProduct(int index, Product newProduct) throws IOException
    {
        allProducts.set(index, newProduct);
    }
       
    /**
     * This method deletes a selected Part
     * @param selectedPart
     * @return 
     */
    public static boolean deletePart(Part selectedPart)
    {  
        for (Part part : getAllParts()) 
        {
            if(part == selectedPart)
                return getAllParts().remove(part);
        }
        return false;
    }
       
    /**
     * This method deletes a selected Product 
     * @param selectedproduct
     * @return 
     */
    public static boolean deleteProduct(Product selectedproduct)
    {
        for (Product product : getAllProducts())
        {
            if(product == selectedproduct)
                return getAllProducts().remove(product);
        }
        return false;
    }
        
   /**
     * This method returns all Parts in the allParts list
     * @return 
     */
     public static ObservableList<Part> getAllParts()
    {
        return allParts;
    }
     
     /**
     * This method returns all Parts in the searchPart list
     * @return 
     */
     public static ObservableList<Part> getSearchParts()
    {
        return searchParts;
    }
          
    /**
     * This method returns all Products in the allProduct list
     * @return 
     */
     public static ObservableList<Product> getAllProducts()
    {
        return allProducts;
    }
     
     /**
     * This method returns all Products in the allProduct list
     * @return 
     */
     public static ObservableList<Product> getSearchProducts()
    {
        return searchProducts;
    }   
}