package inventorymanagementsystem;

import javafx.application.Application;
import static javafx.application.Application.launch;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.ButtonType;
import javafx.stage.Stage;
import model.InHouse;
import model.Inventory;
import model.Outsourced;
import model.Product;

/**
 *
 * @author Daniel Cutrara
 */
public class InventoryManagementSystem extends Application {

   @Override
    public void start(Stage stage) throws Exception {
        Parent root = FXMLLoader.load(getClass().getResource("/View/mainForm.fxml"));
        Scene scene = new Scene(root);
        stage.setScene(scene);
        stage.show();
        
        stage.setOnCloseRequest(event -> 
        {
            event.consume();
            logout(stage);        
        });
    }    
    
    /**
    * This method is called when the Exit button or X is clicked
     * @param stage
    */
    public void logout(Stage stage)
    {
        Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
        alert.setTitle("Exit");
        alert.setHeaderText("You are about to exit the Application");
        alert.setContentText("Are you sure?");
        
        if(alert.showAndWait().get() == ButtonType.OK)
        {
            stage.close();
        }
    }
    
    /**
     *  This method adds sample data to the TableView for Parts and Products
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
        InHouse inhouse1 = new InHouse(1, "Seat", 9.99, 5, 1, 10, 111);
        InHouse inhouse2 = new InHouse(2, "Handle bar", 29.99, 4, 3, 12, 112);
        Outsourced outsource1 = new Outsourced(3, "Rim", 59.99, 2, 2, 8, "Rim Maker");
        Outsourced outsource2 = new Outsourced(4, "Grips", 14.99, 8, 6, 22, "Grip maker");
        InHouse inhouse3 = new InHouse(5, "Safetly lights", 17.99, 3, 1, 14, 115);
        
        Inventory.addPart(inhouse1);
        Inventory.addPart(inhouse2);
        Inventory.addPart(outsource1);
        Inventory.addPart(outsource2);
        Inventory.addPart(inhouse3);
         
        Product product1 = new Product(1, "Dirt Bike", 99.99, 5, 1, 15);
        Product product2 = new Product(2, "Road Bike", 129.99, 3, 2, 8);
        Product product3 = new Product(3, "Cycling shoes", 79.99, 10, 2, 30);
        Product product4 = new Product(4, "Cycling Shirt", 49.99, 10, 4, 24);
        Product product5 = new Product(5, "Kids bike", 49.99, 10, 3, 18);
        
        Inventory.addProduct(product1);
        Inventory.addProduct(product2);
        Inventory.addProduct(product3);
        Inventory.addProduct(product4);
        Inventory.addProduct(product5);
                                
        Inventory.partid = 6;
        Inventory.productid = 6;
                
        launch(args);
    }
}